# badminton > 2025-03-28 6:19pm
https://universe.roboflow.com/kidney-stone-detectionv2iflorence2od/badminton-8yfm2

Provided by a Roboflow user
License: CC BY 4.0

